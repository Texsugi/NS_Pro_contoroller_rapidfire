/* RENCON-MACRO-001 | 2026-10-20
 * USB serial GUI: existing button/LED settings plus four persistent macro presets.
 */
"use strict";

const $ = (id) => document.getElementById(id);
const buttonNames = ["A", "B", "X", "Y", "L", "R", "ZL", "ZR", "UP", "DOWN", "LEFT", "RIGHT", "HOME", "SS", "+", "-"];
let port = null, reader = null, inputBuffer = "", readLoopPromise = null, waitingForStatus = false, statusTimeout = null;
let currentButtonModes = Array(16).fill("OFF");
const connectBtn = $("connectBtn"), disconnectBtn = $("disconnectBtn"), readBtn = $("readBtn"), ledOnBtn = $("ledOnBtn"), ledOffBtn = $("ledOffBtn");

function setMessage(message, kind = "normal") {
  $("statusMessage").textContent = message;
  $("statusMessage").style.color = kind === "error" ? "var(--red)" : kind === "success" ? "var(--green)" : "var(--muted)";
}
function setBadge(text, kind) { const badge = $("connectionBadge"); badge.textContent = text; badge.className = `badge ${kind}`; }
function setConnected(connected) {
  connectBtn.disabled = connected; disconnectBtn.disabled = !connected; readBtn.disabled = !connected;
  ledOnBtn.disabled = !connected; ledOffBtn.disabled = !connected;
  document.querySelectorAll(".save-macro-btn,.apply-setting-btn,.add-step-btn,.remove-step-btn").forEach((b) => { b.disabled = !connected; });
  setBadge(connected ? "接続中" : "未接続", connected ? "connected" : "idle");
}
function showRaw(data) { $("rawData").textContent = typeof data === "string" ? data : JSON.stringify(data, null, 2); }
function modeLabel(mode) { const labels = { OFF: "OFF", RAPID: "連射", DOUBLE: "ダブル", TOGGLE: "トグル" }; return labels[String(mode ?? "").toUpperCase()] || (mode ?? "不明"); }
function makeSelect(options, value, className = "macro-input") {
  const el = document.createElement("select"); el.className = className;
  options.forEach(([v, label]) => { const o = document.createElement("option"); o.value = String(v); o.textContent = label; el.appendChild(o); });
  el.value = String(value); return el;
}
function makeField(labelText, input) { const label = document.createElement("label"); label.className = "field"; const span = document.createElement("span"); span.textContent = labelText; label.append(span, input); return label; }
function addCheck(labelText, checked, className = "check-line") { const label = document.createElement("label"); label.className = className; const input = document.createElement("input"); input.type = "checkbox"; input.checked = Boolean(checked); const span = document.createElement("span"); span.textContent = labelText; label.append(input, span); return { label, input }; }

function effectiveButtonMode(index) {
  const row = $("buttonRows").querySelector(`tr[data-button-index="${index}"]`);
  return String(row?.querySelector(".mode-select")?.value ?? currentButtonModes[index] ?? "OFF").toUpperCase();
}
function buttonHasRapidMode(index) { return effectiveButtonMode(index) !== "OFF"; }
function showMacroButtonConflict(name, role) {
  const message = `${name} は連射設定が優先されるため、マクロの${role}には登録できません。先に連射モードを OFF にするか、別のボタンを選択してください。`;
  window.alert(message);
  setMessage(message, "error");
}
function refreshMacroButtonAvailability() {
  document.querySelectorAll(".macro-trigger-a,.macro-trigger-b,.step-buttons").forEach((select) => {
    [...select.options].forEach((option) => {
      const blocked = buttonHasRapidMode(Number(option.value));
      option.classList.toggle("blocked-option", blocked);
      option.title = blocked ? "連射設定が優先されるためマクロには登録できません" : "";
      option.setAttribute("aria-disabled", blocked ? "true" : "false");
    });
    select.classList.toggle("has-button-conflict",
      [...select.selectedOptions].some((option) => buttonHasRapidMode(Number(option.value))));
  });
}
function bindTriggerSelect(select, role) {
  let previousValue = String(select.value);
  select.addEventListener("change", () => {
    const value = Number(select.value);
    if (buttonHasRapidMode(value)) {
      showMacroButtonConflict(buttonNames[value], role);
      select.value = previousValue;
    } else {
      previousValue = String(select.value);
    }
    refreshMacroButtonAvailability();
  });
}
function bindStepButtonSelect(select) {
  select.addEventListener("change", () => {
    const blocked = [...select.selectedOptions].filter((option) => buttonHasRapidMode(Number(option.value)));
    if (blocked.length) {
      const names = blocked.map((option) => buttonNames[Number(option.value)]).join("、");
      blocked.forEach((option) => { option.selected = false; });
      showMacroButtonConflict(names, "操作ボタン");
    }
    refreshMacroButtonAvailability();
  });
}
function addFrameTimingHints(field, input) {
  const range = document.createElement("small");
  range.className = "input-hint";
  range.textContent = "範囲: 1～600 F（約16.7～10,000 ms）";
  const converted = document.createElement("small");
  converted.className = "duration-ms";
  const update = () => {
    const frames = Number(input.value);
    converted.textContent = Number.isFinite(frames) && frames > 0
      ? `換算: 約 ${(frames * 1000 / 60).toFixed(1)} ms`
      : "換算: — ms";
  };
  input.addEventListener("input", update);
  field.append(range, converted);
  update();
}

function renderStatus(data) {
  if (!data || typeof data !== "object") throw new Error("受信データがJSONオブジェクトではありません。");
  if (data.type && data.type !== "status") throw new Error(`想定外の応答 type: ${data.type}`);
  $("fwVersion").textContent = data.firmware ?? "不明";
  $("deviceState").textContent = data.device_state ?? "応答あり";
  $("rainbowState").textContent = typeof data.rainbow_enabled === "boolean" ? (data.rainbow_enabled ? "ON" : "OFF") : "不明";
  const buttons = Array.isArray(data.buttons) ? data.buttons : [];
  currentButtonModes = Array.from({ length: 16 }, (_, i) =>
    String(buttons[i]?.mode ?? "OFF").toUpperCase());
  $("buttonCount").textContent = `${buttons.length} / 16`;
  const tbody = $("buttonRows"); tbody.replaceChildren();
  if (!buttons.length) {
    const tr = document.createElement("tr"), td = document.createElement("td"); td.colSpan = 5; td.className = "empty"; td.textContent = "応答にボタン設定が含まれていません。"; tr.appendChild(td); tbody.appendChild(tr);
  } else buttons.forEach((button, index) => {
    const tr = document.createElement("tr"), name = button.name ?? buttonNames[index] ?? `BUTTON_${index + 1}`;
    tr.dataset.buttonIndex = String(index);
    const nameTd = document.createElement("td"); nameTd.textContent = String(name); tr.appendChild(nameTd);
    const modeTd = document.createElement("td"), modeSelect = makeSelect([["OFF","OFF"],["RAPID","Mode 1：連射"],["DOUBLE","Mode 2：ダブル"],["TOGGLE","Mode 3：トグル"]], ["OFF","RAPID","DOUBLE","TOGGLE"].includes(String(button.mode).toUpperCase()) ? String(button.mode).toUpperCase() : "OFF", "setting-input mode-select");
    modeSelect.setAttribute("aria-label", `${name} 連射モード`);
    modeSelect.addEventListener("change", refreshMacroButtonAvailability);
    modeTd.appendChild(modeSelect); tr.appendChild(modeTd);
    const offInput = document.createElement("input"); offInput.type = "number"; offInput.className = "setting-input time-input"; offInput.min = "50"; offInput.max = "500"; offInput.step = "5"; offInput.value = Number.isFinite(Number(button.off_ms)) ? Number(button.off_ms) : 250;
    const offTd = document.createElement("td"); offTd.appendChild(offInput); tr.appendChild(offTd);
    const onInput = document.createElement("input"); onInput.type = "number"; onInput.className = "setting-input time-input"; onInput.min = "20"; onInput.max = "500"; onInput.step = "5"; onInput.value = Number.isFinite(Number(button.on_ms)) ? Number(button.on_ms) : 35;
    const onTd = document.createElement("td"); onTd.appendChild(onInput); tr.appendChild(onTd);
    const actionTd = document.createElement("td"), applyBtn = document.createElement("button"); applyBtn.className = "apply-setting-btn"; applyBtn.textContent = "設定を反映"; applyBtn.disabled = !port?.writable;
    applyBtn.addEventListener("click", () => applyButtonSettings(index, name, modeSelect, offInput, onInput, applyBtn)); actionTd.appendChild(applyBtn); tr.appendChild(actionTd); tbody.appendChild(tr);
  });
  renderMacros(Array.isArray(data.macros) ? data.macros : null);
  refreshMacroButtonAvailability();
  $("lastRead").textContent = `最終取得: ${new Date().toLocaleTimeString()}`; showRaw(data); setMessage("本体の状態を取得しました。", "success");
}

function renderMacros(macros) {
  const root = $("macroPresets"); root.replaceChildren();
  if (!macros) { const p = document.createElement("p"); p.className = "empty"; p.textContent = "本体からマクロ設定が返されませんでした。macro.c / macro.h 対応ファームウェアが必要です。"; root.appendChild(p); return; }
  for (let i = 0; i < 4; i++) {
    const preset = macros[i] ?? { enabled:false, loop:false, trigger_a:2, trigger_b:8, pass_trigger:false, steps:[] };
    const card = document.createElement("article"); card.className = "macro-card"; card.dataset.preset = String(i);
    const head = document.createElement("div"); head.className = "macro-card-head"; const title = document.createElement("h3"); title.textContent = `プリセット ${i + 1}`; head.appendChild(title);
    const enabled = addCheck("有効", preset.enabled); enabled.label.className = "check-line"; enabled.input.className = "macro-enabled"; head.appendChild(enabled.label); card.appendChild(head);
    const opts = document.createElement("div"); opts.className = "macro-options";
    const loop = addCheck("ループ実行", preset.loop); loop.input.className = "macro-loop";
    const pass = addCheck("起動ボタンをゲームへ送る", preset.pass_trigger); pass.input.className = "macro-pass-trigger";
    opts.append(loop.label, pass.label);
    const trigA = makeSelect(buttonNames.map((n, idx) => [idx, n]), preset.trigger_a ?? 2); trigA.className = "macro-input macro-trigger-a";
    const trigB = makeSelect(buttonNames.map((n, idx) => [idx, n]), preset.trigger_b ?? 8); trigB.className = "macro-input macro-trigger-b";
    bindTriggerSelect(trigA, "起動ボタン");
    bindTriggerSelect(trigB, "起動ボタン");
    opts.append(makeField("起動ボタン1", trigA), makeField("起動ボタン2", trigB)); card.appendChild(opts);
    const stepsRoot = document.createElement("div"); stepsRoot.className = "macro-steps"; card.appendChild(stepsRoot);
    const stepData = Array.isArray(preset.steps) ? preset.steps.slice(0,20) : [];
    stepData.forEach((step, stepIndex) => addStepRow(stepsRoot, step, stepIndex));
    const actions = document.createElement("div"); actions.className = "macro-actions";
    const addBtn = document.createElement("button"); addBtn.type = "button"; addBtn.className = "add-step-btn"; addBtn.textContent = "＋ 操作を追加"; addBtn.disabled = !port?.writable;
    addBtn.addEventListener("click", () => { if (stepsRoot.children.length >= 20) { setMessage("1プリセットの操作数は最大20です。", "error"); return; } addStepRow(stepsRoot, {mask:1,hold_frames:1,wait_frames:1}, stepsRoot.children.length); });
    const saveBtn = document.createElement("button"); saveBtn.type = "button"; saveBtn.className = "save-macro-btn"; saveBtn.textContent = "プリセットを保存"; saveBtn.disabled = !port?.writable; saveBtn.addEventListener("click", () => saveMacroPreset(card, saveBtn));
    actions.append(addBtn, saveBtn); card.appendChild(actions); root.appendChild(card);
  }
  refreshMacroButtonAvailability();
}

function addStepRow(root, step, index) {
  const row = document.createElement("div"); row.className = "macro-step";
  const title = document.createElement("div"); title.className = "step-title"; const label = document.createElement("span"); label.textContent = `操作 ${index + 1}`;
  const remove = document.createElement("button"); remove.type = "button"; remove.className = "remove-step-btn danger-btn"; remove.textContent = "削除"; remove.disabled = !port?.writable; remove.addEventListener("click", () => { row.remove(); renumberSteps(root); }); title.append(label, remove); row.appendChild(title);
  const fields = document.createElement("div"); fields.className = "step-fields";
  const buttonsSelect = document.createElement("select"); buttonsSelect.multiple = true; buttonsSelect.size = 4; buttonsSelect.className = "macro-input step-buttons"; buttonsSelect.setAttribute("aria-label", `操作 ${index + 1} のボタン`);
  const mask = Number(step.mask) || 0;
  buttonNames.forEach((name, bit) => { const option = document.createElement("option"); option.value = String(bit); option.textContent = name; option.selected = Boolean(mask & (1 << bit)); buttonsSelect.appendChild(option); });
  bindStepButtonSelect(buttonsSelect);
  const hold = document.createElement("input"); hold.type = "number"; hold.min = "1"; hold.max = "600"; hold.step = "1"; hold.value = Number(step.hold_frames) || 1; hold.className = "macro-input step-hold";
  const wait = document.createElement("input"); wait.type = "number"; wait.min = "1"; wait.max = "600"; wait.step = "1"; wait.value = Number(step.wait_frames) || 1; wait.className = "macro-input step-wait";
  const holdField = makeField("押下 F", hold), waitField = makeField("待ち F", wait);
  addFrameTimingHints(holdField, hold);
  addFrameTimingHints(waitField, wait);
  fields.append(makeField("ボタン（複数選択可）", buttonsSelect), holdField, waitField); row.appendChild(fields);
  const help = document.createElement("p"); help.className = "step-help"; help.textContent = "複数ボタンを同時に押す場合は Ctrl（Macは⌘）を押しながら選択。1F ≈ 16.67ms（60Hz換算）。"; row.appendChild(help); root.appendChild(row);
  refreshMacroButtonAvailability();
}
function renumberSteps(root) { [...root.children].forEach((row, i) => { const label = row.querySelector(".step-title span"); if (label) label.textContent = `操作 ${i + 1}`; }); }

async function saveMacroPreset(card, button) {
  if (!port?.writable) { setMessage("USB接続がありません。", "error"); return; }
  const index = Number(card.dataset.preset), enabled = card.querySelector(".macro-enabled").checked, loop = card.querySelector(".macro-loop").checked;
  const triggerA = Number(card.querySelector(".macro-trigger-a").value), triggerB = Number(card.querySelector(".macro-trigger-b").value), pass = card.querySelector(".macro-pass-trigger").checked;
  const rows = [...card.querySelectorAll(".macro-step")];
  if (triggerA === triggerB) { setMessage(`プリセット${index + 1}: 起動ボタンは異なる2つを選択してください。`, "error"); return; }
  if (buttonHasRapidMode(triggerA) || buttonHasRapidMode(triggerB)) {
    const blocked = [triggerA, triggerB].filter(buttonHasRapidMode).map((bit) => buttonNames[bit]).join("、");
    showMacroButtonConflict(blocked, "起動ボタン");
    return;
  }
  if (enabled) {
    for (const other of document.querySelectorAll(".macro-card")) {
      if (other === card || !other.querySelector(".macro-enabled").checked) continue;
      const a = Number(other.querySelector(".macro-trigger-a").value), b = Number(other.querySelector(".macro-trigger-b").value);
      if ((a === triggerA && b === triggerB) || (a === triggerB && b === triggerA)) {
        setMessage("有効なプリセット同士で起動ボタンの組み合わせを重複させないでください。", "error"); return;
      }
    }
  }
  if (rows.length > 20 || (enabled && rows.length === 0)) { setMessage("有効なプリセットには1～20操作を登録してください。", "error"); return; }
  const values = [];
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i], selected = [...row.querySelector(".step-buttons").selectedOptions].map(o => Number(o.value));
    const hold = Number(row.querySelector(".step-hold").value), wait = Number(row.querySelector(".step-wait").value);
    if (!selected.length) { setMessage(`操作${i + 1}: ボタンを1つ以上選択してください。`, "error"); return; }
    const blocked = selected.filter(buttonHasRapidMode);
    if (blocked.length) {
      showMacroButtonConflict(blocked.map((bit) => buttonNames[bit]).join("、"), `操作${i + 1}の操作ボタン`);
      return;
    }
    if (!Number.isInteger(hold) || hold < 1 || hold > 600 || !Number.isInteger(wait) || wait < 1 || wait > 600) { setMessage(`操作${i + 1}: 押下F・待ちFは1～600の整数で入力してください。`, "error"); return; }
    const mask = selected.reduce((m, bit) => m | (1 << bit), 0); values.push(mask, hold, wait);
  }
  const command = `SET_MACRO,${index},${Number(enabled)},${Number(loop)},${triggerA},${triggerB},${Number(pass)},${rows.length}${values.length ? "," + values.join(",") : ""}\n`;
  try {
    button.disabled = true; const writer = port.writable.getWriter(); await writer.write(new TextEncoder().encode(command)); writer.releaseLock();
    setMessage(`プリセット${index + 1}を送信しました。保存結果を確認しています…`); window.setTimeout(() => { if (port?.writable) requestStatus(); }, 250);
  } catch (error) { setMessage(`マクロ設定送信エラー: ${error.message}`, "error"); }
  finally { button.disabled = !port?.writable; }
}

function handleLine(line) {
  const trimmed = line.trim(); if (!trimmed) return; showRaw(trimmed); let data;
  try { data = JSON.parse(trimmed); } catch { setMessage(`JSON以外の応答を受信: ${trimmed.slice(0,120)}`); return; }
  if (data.type === "status" || Array.isArray(data.buttons)) {
    waitingForStatus = false; if (statusTimeout) clearTimeout(statusTimeout);
    try { renderStatus(data); } catch (error) { setMessage(error.message, "error"); }
  } else if (data.type === "success") { setMessage(data.message ?? "本体が設定を保存しました。", "success"); }
  else if (data.type === "error") { waitingForStatus = false; if (statusTimeout) clearTimeout(statusTimeout); setMessage(`本体エラー: ${data.message ?? "詳細不明"}`, "error"); }
}
async function readLoop() {
  if (!port?.readable) return; const decoder = new TextDecoder();
  try {
    reader = port.readable.getReader();
    while (true) { const { value, done } = await reader.read(); if (done) break; inputBuffer += decoder.decode(value, {stream:true}); let newline;
      while ((newline = inputBuffer.indexOf("\n")) >= 0) { const line = inputBuffer.slice(0,newline); inputBuffer = inputBuffer.slice(newline+1); handleLine(line); }
      if (inputBuffer.length > 8192) { showRaw(inputBuffer); inputBuffer = ""; }
    }
  } catch (error) { if (port) setMessage(`USB受信エラー: ${error.message}`, "error"); }
  finally { try { reader?.releaseLock(); } catch {} reader = null; }
}
async function connect() {
  if (!("serial" in navigator)) { setBadge("非対応ブラウザ","error"); setMessage("Web Serial APIに対応したChromeまたはEdgeで開いてください。","error"); return; }
  try { port = await navigator.serial.requestPort(); await port.open({baudRate:115200}); setConnected(true); setMessage("USBポートを開きました。状態を取得してください。","success"); readLoopPromise = readLoop(); navigator.serial.addEventListener("disconnect",onDisconnect); }
  catch (error) { port = null; setConnected(false); setMessage(`接続できませんでした: ${error.message}`,"error"); setBadge("接続失敗","error"); }
}
async function requestStatus() {
  if (!port?.writable) { setMessage("USB接続がありません。","error"); return; }
  try { waitingForStatus = true; setMessage("本体に状態を問い合わせています…"); const writer = port.writable.getWriter(); await writer.write(new TextEncoder().encode("GET_STATUS\n")); writer.releaseLock(); if (statusTimeout) clearTimeout(statusTimeout);
    statusTimeout = setTimeout(() => { if (waitingForStatus) { waitingForStatus = false; setMessage("応答がありません。macro.c / macro.h 対応ファームウェアか確認してください。","error"); } },3000);
  } catch (error) { waitingForStatus = false; setMessage(`問い合わせ送信エラー: ${error.message}`,"error"); }
}
async function setLed(enabled) {
  if (!port?.writable) { setMessage("USB接続がありません。","error"); return; }
  try { const writer = port.writable.getWriter(); await writer.write(new TextEncoder().encode(`${enabled ? "SET_LED_ON" : "SET_LED_OFF"}\n`)); writer.releaseLock(); setMessage(`RGB LED ${enabled ? "ON" : "OFF"} コマンドを送信しました。`,`success`); window.setTimeout(() => { if (port?.writable) requestStatus(); },150); }
  catch (error) { setMessage(`RGB LEDコマンド送信エラー: ${error.message}`,"error"); }
}
async function applyButtonSettings(index, name, modeSelect, offInput, onInput, applyBtn) {
  if (!port?.writable) { setMessage("USB接続がありません。","error"); return; }
  const offMs = Number(offInput.value), onMs = Number(onInput.value);
  if (!Number.isInteger(offMs) || offMs < 50 || offMs > 500 || offMs % 5 !== 0) { setMessage(`${name} のOFF時間は50～500 ms、5 ms刻みで入力してください。`,`error`); offInput.focus(); return; }
  if (!Number.isInteger(onMs) || onMs < 20 || onMs > 500 || onMs % 5 !== 0) { setMessage(`${name} のON時間は20～500 ms、5 ms刻みで入力してください。`,`error`); onInput.focus(); return; }
  try { applyBtn.disabled = true; const writer = port.writable.getWriter(); await writer.write(new TextEncoder().encode(`SET_BUTTON,${index},${modeSelect.value},${offMs},${onMs}\n`)); writer.releaseLock(); setMessage(`${name} の設定を送信しました。保存結果を確認しています…`); window.setTimeout(() => { if (port?.writable) requestStatus(); },250); }
  catch (error) { setMessage(`${name} の設定送信エラー: ${error.message}`,"error"); }
  finally { applyBtn.disabled = !port?.writable; }
}
async function disconnect() {
  const oldPort = port; port = null;
  try { if (reader) { try { await reader.cancel(); } catch {} } if (oldPort) await oldPort.close(); }
  catch (error) { setMessage(`切断時の注意: ${error.message}`,"error"); }
  if (statusTimeout) clearTimeout(statusTimeout); setConnected(false); setMessage("USBを切断しました。");
}
function onDisconnect() { port = null; if (statusTimeout) clearTimeout(statusTimeout); setConnected(false); setMessage("USBデバイスが切断されました。","error"); }
connectBtn.addEventListener("click",connect); disconnectBtn.addEventListener("click",disconnect); readBtn.addEventListener("click",requestStatus); ledOnBtn.addEventListener("click",()=>setLed(true)); ledOffBtn.addEventListener("click",()=>setLed(false));
if (!("serial" in navigator)) setMessage("このブラウザではWeb Serial APIを利用できません。Chrome / Edgeで開いてください。","error");
